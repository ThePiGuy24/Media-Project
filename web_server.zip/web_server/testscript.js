function randint(min, max) {
	return Math.floor(Math.random() * (max - min) ) + min;
}

function pizza() {
	document.getElementById("thingy").innerHTML = randint(0,10000000000000000000000000000000000000);
}

function redirect(loc) {
	window.location.href = loc;
}
//var body = document.getElementsByTagName('body')[0];
//var img = randint(1,3);
//if (img == 1) {
//	body.style.backgroundImage = 'url(/favicon.png)';
//} else {
//	if (img == 2) {
//		body.style.backgroundImage = 'url(/Logo.png)';
//	} else {
//		if (img == 3) {
//			body.style.backgroundImage = 'url(/placeholder.png)';
//		}
//	}
//}