var r = false;

function randint(min, max) {
	return Math.floor(Math.random() * (max - min) ) + min;
}

function drawline(sx, sy, ex, ey) {
	var ctx = document.getElementById("myCanvas").getContext("2d");
	ctx.moveTo(sx, sy);
	ctx.lineTo(ex, ey);
	ctx.stroke();
}

function rad(deg) {
	return deg * Math.PI / 180;
}

function drawcircle(x, y, rd) {
	var c = 0
	for (i=0; i<Math.round(360/rd); i++) {
		r = rad(i*(rd/360))
		rr = rad((i-1)*(rd/360))
		drawline(Math.sin(rr)*rd+x,Math.cos(rr)*rd+y,Math.sin(r)*rd+x,Math.cos(r)*rd+y);
		c = c + 1
	}
	console.log(c)
}

function pizza() {
	drawcircle(randint(0,512),randint(0,512),randint(0,512))
}